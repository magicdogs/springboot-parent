This package contains generated TLS certificates to be used with Search Guard.

Structure:                                                             

search-guard-certificates-<UUID>.tar.gz 
│
└─── client-certificates
│        Contains two client certificates named 'admin' and 'demouser'
│        The admin certificate can be used with sgadmin and the REST API. 
│        The CN of this certificate is 'sgadmin'. The demouser certificate can be used 
│        for HTTPS client authentication. 
└─── node-certificates
│        Contains the certificates in jks, p12 and pem format to be used 
│        on your Elasticsearch nodes. You will find certificates for all 
│        hostnames you specified when submitting the form.
└─── root-ca
│        Contains the root CA certificate and private key.
└─── config
│        Same as above, but for the signing CA
└─── truststore.jks
│        The truststore containing the certificate chain
│        of the root and signing CA. Can be used on all nodes.
                                                             
                                                             
Passwords:                                                             

CA password: 6a488b03c6a84f4e249fd55cc302fd1d72dee900                                       
Truststore password: e4780b3a3d2a7a67514c                               
Admin keystore password: 671221a7fe53860f56ca                       
Demouser keystore password: 48c2f23d7d7a4993d48d               
                                                              
                                                             
                                                             
Host: www.mscnut.top                                                 
www.mscnut.top keystore password: 06751f402fa0180c138d                           
                                                             
searchguard.authcz.admin_dn:                                
  - CN=sgadmin  
